package com.cap.anurag.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cap.anurag.entities.Employee;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	RestTemplate rest;

	@GetMapping("/find/{id}")
	public Employee getEmployeeById(@PathVariable("id") Integer id) {
		Employee emp=rest.getForObject("http://localhost:7878/employees/find/"+id, Employee.class);
		return emp;
	}

	@RequestMapping("/create")
	public String create(@RequestBody Employee employee) {
		//rest.getForObject("http://localhost:7871/employees/create",Employee.class);
		rest.postForObject("http://localhost:7871/employees/create", employee,Employee.class);
		return "Created";
	}

	@RequestMapping("/update")
	public Employee update(@RequestBody Employee employee) {
		Employee emp=rest.postForObject("http://localhost:7874/employees/update", employee, Employee.class);
		return emp;
	}

	@RequestMapping("/delete/{id}")
	public String deleteEmployeeById(@PathVariable("id") Integer id) {
		Employee emp=rest.getForObject("http://localhost:7872/employees/delete/"+id, Employee.class);
		if(emp==null)
			return "deleted";
		return "not deleted";
	}

}